<?php
/**
 * @package		JomSocial
 * @subpackage	Core 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
?>

<?php echo JText::sprintf('COM_COMMUNITY_EMAIL_PROFILE_ACTIVITYCOMMENT', $message); ?>