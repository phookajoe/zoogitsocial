<?php
defined('_JEXEC') or die();
?>
<?php echo JText::_('COM_COMMUNITY_SUCCESS'); ?>