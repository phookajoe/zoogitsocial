<?php
/**
 * @category	Core
 * @package		JomSocial
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 */
// Disallow direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<div id="config-document">
	<div id="page-basic" class="tab">
		<table class="noshow">
			<tr>
				<td>User</td>
			</tr>
		</table>
	</div>
	<div id="page-image" class="tab">
		<table class="noshow">
			<tr>
				<td>Media</td>
			</tr>
		</table>
	</div>
	<div id="page-video" class="tab">
		<table class="noshow">
			<tr>
				<td>Groups and Events</td>
			</tr>
		</table>
	</div>
</div>